package com.example.telegramarchive.data.export

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.example.telegramarchive.data.ArchivedMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class TxtWriter(private val context: Context) {
    private val mutex = Mutex()

    suspend fun append(folder: Uri, message: ArchivedMessage) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val fileName = "${safeFileName(message.chatTitle)}_${message.chatId}.txt"
            val resolver = context.contentResolver
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
                folder, DocumentsContract.getTreeDocumentId(folder)
            )
            val existingFile = resolver.query(
                childrenUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME
                ),
                null, null, null
            )?.use { cursor ->
                val nameIndex = cursor.getColumnIndexOrThrow(
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME
                )
                val idIndex = cursor.getColumnIndexOrThrow(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID
                )
                var found: Uri? = null
                while (cursor.moveToNext()) {
                    if (cursor.getString(nameIndex) == fileName) {
                        found = DocumentsContract.buildDocumentUriUsingTree(
                            folder, cursor.getString(idIndex)
                        )
                        break
                    }
                }
                found
            }

            val fileUri = existingFile ?: DocumentsContract.createDocument(
                resolver, folder, "text/plain", fileName
            ) ?: error("Не удалось создать файл $fileName")

            val date = SimpleDateFormat(
                "dd.MM.yyyy HH:mm:ss", Locale.getDefault()
            ).format(Date(message.timestamp * 1000))
            val entry = buildString {
                append("[$date] ")
                appendLine(message.sender)
                appendLine(message.text)
                appendLine()
            }

            // Поддержка append зависит от DocumentProvider; проверяйте на целевом телефоне.
            resolver.openOutputStream(fileUri, "wa")?.bufferedWriter(Charsets.UTF_8)?.use {
                it.append(entry)
            } ?: error("Не удалось открыть файл для добавления")
        }
    }

    private fun safeFileName(value: String): String =
        value.replace(Regex("""[/\\:*?"<>|]"""), "_")
            .trim().take(80).ifBlank { "Telegram_chat" }
}
