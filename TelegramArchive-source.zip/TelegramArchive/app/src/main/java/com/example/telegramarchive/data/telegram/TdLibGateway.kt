package com.example.telegramarchive.data.telegram

/**
 * Точка интеграции официальной TDLib Android-библиотеки.
 * Реализуйте адаптер под конкретную версию TDLib.
 */
interface TdLibGateway {
    suspend fun connect()
    suspend fun loadChats()
    suspend fun importHistory(chatId: Long)
    fun startLiveUpdates()
    fun stop()
}
