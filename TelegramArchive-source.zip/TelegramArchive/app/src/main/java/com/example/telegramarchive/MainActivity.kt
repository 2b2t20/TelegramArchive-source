package com.example.telegramarchive

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.telegramarchive.data.ArchivedMessage
import com.example.telegramarchive.data.export.TxtWriter
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val writer = TxtWriter(this)
        setContent {
            MaterialTheme {
                var folder by remember { mutableStateOf<Uri?>(null) }
                var folderLabel by remember { mutableStateOf("Папка не выбрана") }
                var importHistory by remember { mutableStateOf(true) }
                var trackEdits by remember { mutableStateOf(true) }
                var status by remember { mutableStateOf("TDLib ещё не подключена") }
                val scope = rememberCoroutineScope()

                val picker = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocumentTree()
                ) { uri ->
                    if (uri != null) {
                        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        runCatching { contentResolver.takePersistableUriPermission(uri, flags) }
                        folder = uri
                        folderLabel = uri.toString()
                    }
                }

                Surface(Modifier.fillMaxSize()) {
                    LazyColumn(
                        Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text("Telegram Archive", style = MaterialTheme.typography.headlineMedium)
                            Text("Архив доступных облачных диалогов в TXT")
                        }
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Подключение Telegram", style = MaterialTheme.typography.titleMedium)
                                    Text(status)
                                    Text("Подключение пользовательского аккаунта появится после интеграции официальной TDLib.")
                                    Button(onClick = {
                                        status = "TDLib не подключена. См. README.md для следующего этапа."
                                    }) { Text("Проверить подключение") }
                                }
                            }
                        }
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Настройки архива", style = MaterialTheme.typography.titleMedium)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(importHistory, { importHistory = it })
                                        Text("Импортировать доступную историю")
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(trackEdits, { trackEdits = it })
                                        Text("Фиксировать обнаруженные изменения/удаления")
                                    }
                                    Text("История: ${if (importHistory) "включена" else "выключена"}")
                                    Text("Изменения: ${if (trackEdits) "включены" else "выключены"}")
                                    Text("Секретные чаты не поддерживаются.")
                                }
                            }
                        }
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Папка TXT", style = MaterialTheme.typography.titleMedium)
                                    Text(folderLabel, style = MaterialTheme.typography.bodySmall)
                                    Button(onClick = { picker.launch(null) }) { Text("Выбрать папку") }
                                }
                            }
                        }
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Проверка TXT-записи", style = MaterialTheme.typography.titleMedium)
                                    Text("Создаёт тестовую запись в выбранной папке.")
                                    OutlinedButton(onClick = {
                                        val target = folder
                                        if (target == null) {
                                            status = "Сначала выберите папку"
                                        } else {
                                            scope.launch {
                                                runCatching {
                                                    writer.append(
                                                        target,
                                                        ArchivedMessage(
                                                            chatId = 1L,
                                                            messageId = System.currentTimeMillis(),
                                                            chatTitle = "Тест",
                                                            sender = "Telegram Archive",
                                                            timestamp = System.currentTimeMillis() / 1000,
                                                            text = "Тестовая запись. TDLib пока не подключена."
                                                        )
                                                    )
                                                }.onSuccess {
                                                    status = "Тестовая запись сохранена"
                                                }.onFailure {
                                                    status = "Ошибка записи: ${it.message}"
                                                }
                                            }
                                        }
                                    }) { Text("Записать тест в TXT") }
                                    Text(status)
                                }
                            }
                        }
                        item {
                            Text(
                                "Это стартовый каркас UI и экспорта, а не готовый Telegram-клиент. См. README.md.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}
