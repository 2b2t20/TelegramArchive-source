package com.example.telegramarchive.data.db

/**
 * Модель для следующего этапа Room.
 * Каждая версия сохраняется отдельно, исходный текст не затирается.
 */
data class MessageVersion(
    val chatId: Long,
    val messageId: Long,
    val observedAtEpochSeconds: Long,
    val originalDateEpochSeconds: Long,
    val text: String,
    val eventType: String // NEW, EDIT, DELETE_OBSERVED
)
