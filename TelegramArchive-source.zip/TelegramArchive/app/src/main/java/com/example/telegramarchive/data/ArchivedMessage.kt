package com.example.telegramarchive.data

data class ArchivedMessage(
    val chatId: Long,
    val messageId: Long,
    val chatTitle: String,
    val sender: String,
    val timestamp: Long,
    val text: String
)
